import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import http from "http";
import { Server } from "socket.io";

import restaurantRoutes from "./routes/restaurantRoutes.js";
import restaurantPagesRoutes from "./routes/restaurantPagesRoutes.js";
import restaurantApiRoutes from "./routes/restaurantApiRoutes.js";

import { moveSongToBottomAfterPlayed } from "./data/store.js";

const app = express();
const server = http.createServer(app);

const io = new Server(server, { cors: { origin: "*" } });

const PORT = process.env.PORT || 3000;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ===== MIDDLEWARES =====
app.use(express.json());
app.set("trust proxy", true);

// ===== SOCKET.IO =====
io.on("connection", (socket) => {
  console.log("📡 Cliente conectado:", socket.id);

  socket.on("room:join", ({ room }) => {
    if (!room) return;
    socket.join(room);
    console.log(`🟢 Cliente unido a sala ${room}`);
  });

  // ✅ TV -> server: inició canción (para sincronizar clientes)
  socket.on("song:start", ({ room, songId, startedAt, durationSec }) => {
    if (!room) return;
    io.to(room).emit("song:update", {
      room,
      songId,
      startedAt,
      durationSec,
    });
  });

  // ✅ TV -> server: terminó canción (mover abajo + votos 0)
  socket.on("song:ended", ({ room, songId }) => {
    if (!room || !songId) return;
    const restaurant = moveSongToBottomAfterPlayed(room, songId);
    if (!restaurant) return;

    io.to(room).emit("votes:update", {
      room,
      songs: restaurant.songs,
    });
  });

  socket.on("disconnect", () => {
    console.log("🔴 Cliente desconectado:", socket.id);
  });
});

// para usar io en rutas
app.set("io", io);

// ===== ESTÁTICOS =====
app.use(express.static(path.join(__dirname, "../public")));
app.use("/qrcodes", express.static(path.join(__dirname, "../public/qrcodes")));

// ✅ Admin corto
app.get("/admin", (req, res) => {
  res.sendFile(path.join(__dirname, "../public/admin.html"));
});

// ===== PÁGINAS =====
app.use("/", restaurantPagesRoutes);

// ===== API =====
app.use("/api/restaurants", restaurantRoutes);
app.use("/api/r", restaurantApiRoutes);

// ===== HEALTH =====
app.get("/health", (req, res) => res.json({ ok: true }));

server.listen(PORT, "0.0.0.0", () => {
  console.log("🔥 Servidor corriendo en puerto", PORT);
});