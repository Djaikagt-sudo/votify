import express from "express";
import crypto from "crypto";
import QRCode from "qrcode";
import path from "path";
import { createRestaurant } from "../data/store.js";
import { library } from "../data/library.js";
import { fileURLToPath } from "url";

const router = express.Router();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

router.post("/", async (req, res) => {
  try {
    const { name, genres } = req.body;

    if (!name || !Array.isArray(genres) || genres.length === 0) {
      return res.status(400).json({ error: "Nombre y géneros requeridos" });
    }

    let songs = [];

    genres.forEach(g => {
      if (library[g]) {
        songs = songs.concat(library[g]);
      }
    });

    if (songs.length === 0) {
      return res.status(400).json({ error: "No hay canciones en esos géneros" });
    }

    const id = crypto.randomUUID();

    const restaurant = createRestaurant({
      id,
      name,
      songs
    });

    const baseUrl =
      process.env.PUBLIC_BASE_URL ||
      `${req.protocol}://${req.get("host")}`;

    const votePath = `/r/${id}`;

    // ✅ Ruta absoluta segura
    const qrDir = path.join(__dirname, "../../public/qrcodes");

    // Crear carpeta si no existe
    await import("fs").then(fs => {
      if (!fs.existsSync(qrDir)) {
        fs.mkdirSync(qrDir, { recursive: true });
      }
    });

    const qrFile = path.join(qrDir, `${id}.png`);

    await QRCode.toFile(qrFile, `${baseUrl}${votePath}`);

    res.json({
      ok: true,
      restaurant: {
        id,
        name,
        urls: {
          vote: votePath,
          tv: `/tv/${id}`,
          apiState: `/api/r/${id}/state`,
          qr: `/qrcodes/${id}.png`
        }
      }
    });

  } catch (err) {
    console.error("ERROR QR:", err);
    res.status(500).json({ error: "Error creando restaurante" });
  }
});

export default router;